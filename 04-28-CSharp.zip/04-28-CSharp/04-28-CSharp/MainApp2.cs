﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MBCAcademy;

//알고리즘 
namespace _04_28_CSharp
{
    internal class MainApp2
    {
        #region 재귀호출 메서드
        //static void recursive(int num) // 변수든 메서드든 대소문자 구분 한다.
        //{
        //    if (num <= 0)
        //        return;
        //    //메서드를 빠져나감
        //    //반환값이 int이면 void 대신 int로 바꿔야함
        //    Console.WriteLine($"Recursive Call! : {num}");
        //    recursive(num - 1);
        //}
        //static int Factorial(int n)
        //{
        //    if (n <= 0)
        //        return 1;
        //    return n * Factorial(n - 1);
        //}
        //static void Main(string[] args)
        //{
        //    //recursive(3);
        //    Console.WriteLine(Factorial(1));
        //    Console.WriteLine(Factorial(2));
        //    Console.WriteLine(Factorial(3));
        //    Console.WriteLine(Factorial(4));
        //    Console.WriteLine(Factorial(5));
        //    Console.WriteLine(Factorial(6));
        //}
        #endregion


    }
}
