﻿//namespace _04_28_CSharp
//{
//    internal class Program
//    {
      

//        static void Main(string[] args)
//        {
            
//            Console.WriteLine($"더한 값 : {Plus(10,20)}");
//            Console.WriteLine($"나눈 값 : {Division(100,50)}");
//            Console.WriteLine(Minus(100,50));
//            Console.WriteLine(MultiPly(10,5));
            
//        }

//        private static int Division(int a, int b)
//        {

            
//            return a/b;
//        }

//        private static int Minus(int a, int b)
//        {

            
//            return a-b;
//        }

//        private static int Plus(int a, int b)
//        {
            
//            return a+b;


//        }
//        private static int MultiPly(int a, int b)
//        {

            
//            return a*b;
//        }

        
        
//    }
//}

