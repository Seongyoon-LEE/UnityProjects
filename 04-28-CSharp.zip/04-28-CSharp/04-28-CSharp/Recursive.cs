﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBCAcademy
{
    public class Recursive
    {
        //void : 아무 값도 반환하지 않음 
       
        
    }
}
